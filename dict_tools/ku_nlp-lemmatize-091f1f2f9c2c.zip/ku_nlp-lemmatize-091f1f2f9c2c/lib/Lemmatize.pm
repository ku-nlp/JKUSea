package Lemmatize;

use 5.008001;
use DB_File;
use strict;
use warnings;

our $VERSION = '0.11';
our $word_db_path = $INC{'Lemmatize.pm'};
$word_db_path =~ s|/Lemmatize\.pm$|/Lemmatize_dic.db|
    or die "Can't detect the directory of Lemmatize.pm.\n";

our %exceptions = ('these' => 'this', 'those' => 'that', 'n\'t' => 'not', '\'m' => 'be', '\'ll' => 'will', '\'ve' => 'have', '\'re' => 'are');


# Preloaded methods go here.

sub new {
    my ($this, $opt) = @_;

    $this = {opt => ref($opt) ? {%{$opt}} : {}};

    tie(%{$this->{word}}, 'DB_File', $word_db_path, O_RDONLY) or die "DIC.db: $!\n";
    bless $this;
}

sub lemmatize {
    my ($this, $word, $pos) = @_;
    my (@ret);

    return wantarray ? () : undef unless $word;

    # delete utf8-flag if the word has a utf8-flag
    if (utf8::is_utf8($word)) {
	require Encode;
	$word = Encode::encode('utf8', $word);
    }

    # some exceptions
    if (exists($exceptions{$word})) {
	push(@ret, $exceptions{$word});
    }
    # look up the dictionary
    elsif (exists($this->{word}{$word})) {
	if ($pos and $pos = &pos_trans($pos) and $this->{word}{$word} =~ m|/|) {
	    for my $w (split('/', $this->{word}{$word})) {
		my ($orig, $poss) = split('\|', $w);
		push(@ret, $orig) if grep({$_ eq $pos} split(',', $poss));
	    }
	}

	unless (@ret) {
	    @ret = map({(split('\|', $_))[0]} split('/', $this->{word}{$word}));
	}
    }

    if (@ret) {
	if ($this->{opt}{unique} or !wantarray) {
	    return $ret[0];
	}
	else {
	    return sort({length($a) <=> length($b)} @ret);
	}
    }

    return wantarray ? () : undef;
}

sub pos_trans {
    my ($pos) = @_;

    if ($pos =~ /^(?:VB|MD|AUX)/) {
	return 'V';
    }
    elsif ($pos =~ /^NN/) {
	return 'N';
    }
    elsif ($pos =~ /^(?:IN|TO)/) {
	return 'Prep';
    }
    elsif ($pos =~ /^JJ/) {
	return 'A';
    }
    elsif ($pos =~ /^(?:RB|EX)/) {
	return 'Adv';
    }
    elsif ($pos =~ /^(POS|PRP)/) { # 's
	return 'G';
    }
    return undef;
}

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Lemmatize - Perl extension for lemmatizing English words

=head1 SYNOPSIS

  use Lemmatize;
  $lem = new Lemmatize;
  @orig_words = $lem->lemmatize('looked');

=head1 DESCRIPTION

This perl module lemmatizes english words. It looks up an English
dictionary to get an original form of a given word. The dictionary is
the morphological database developed by the XTAG project at the
University of California at Berkeley.

=head1 SEE ALSO

perl(1)

=head1 AUTHOR

Daisuke Kawahara, E<lt>kawahara@kc.t.u-tokyo.ac.jpE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2005 by Daisuke Kawahara

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


=cut
